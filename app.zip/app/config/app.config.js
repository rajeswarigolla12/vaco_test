export default {
  PERMISSION_SCOPE: 'app1',
};
